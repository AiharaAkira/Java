module Financial {
	exports com.fin.cal;
	exports com.fin.gui;

	requires java.desktop;
	requires java.sql;
}