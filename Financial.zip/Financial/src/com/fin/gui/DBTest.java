package com.fin.gui;

public class DBTest {

	
	public static void main(String[] args) {

		CalDAO calDAO = new CalDAO();
		calDAO.getAllCal();
		
		
	}

}
